// InstaLite download button: saves the photo or video you are looking at.
(() => {
    if (window.__instaLiteDownload) return;
    window.__instaLiteDownload = true;

    const media = {};                 // shortcode -> { items: [{ type, url }] }
    const MAX_JSON = 6 * 1024 * 1024; // ignore huge responses

    // ---------- finding media in Instagram's data ----------

    const area = (c) => (c.width || 0) * (c.height || 0);
    const biggest = (list) =>
        (list && list.length) ? list.slice().sort((a, b) => area(b) - area(a))[0].url || null : null;

    // One post can be a single photo, a single video, or a carousel of both.
    const itemsOf = (node) => {
        const out = [];
        const add = (n) => {
            const video = biggest(n.video_versions) || n.video_url || null;
            if (video) { out.push({ type: 'video', url: video }); return; }
            const image = biggest(n.image_versions2 && n.image_versions2.candidates) || n.display_url || null;
            if (image) out.push({ type: 'image', url: image });
        };
        if (Array.isArray(node.carousel_media) && node.carousel_media.length) {
            node.carousel_media.forEach(add);
        } else if (node.edge_sidecar_to_children && Array.isArray(node.edge_sidecar_to_children.edges)) {
            node.edge_sidecar_to_children.edges.forEach((e) => e && e.node && add(e.node));
        } else {
            add(node);
        }
        return out;
    };

    const looksLikeMedia = (n) =>
        !!(n.video_versions || n.image_versions2 || n.video_url || n.display_url || n.carousel_media);

    const scan = (node, depth) => {
        depth = depth || 0;
        if (!node || typeof node !== 'object' || depth > 40) return;
        if (Array.isArray(node)) {
            for (let i = 0; i < node.length; i++) scan(node[i], depth + 1);
            return;
        }
        const code = node.code || node.shortcode;
        if (typeof code === 'string' && looksLikeMedia(node)) {
            const items = itemsOf(node);
            if (items.length) media[code] = { items };
        }
        for (const key in node) {
            const value = node[key];
            if (value && typeof value === 'object') scan(value, depth + 1);
        }
    };

    const tryParse = (text) => { try { return JSON.parse(text); } catch (_) { return null; } };

    const parseAndScan = (text) => {
        if (!text || text.length > MAX_JSON) return;
        if (text.indexOf('video_versions') < 0 && text.indexOf('image_versions2') < 0 &&
            text.indexOf('display_url') < 0 && text.indexOf('video_url') < 0) return;
        const cleaned = text.replace(/^for \(;;\);/, '');
        const whole = tryParse(cleaned);
        if (whole) { scan(whole); return; }
        cleaned.split('\n').forEach((line) => { const d = tryParse(line); if (d) scan(d); });
    };

    const scanDocument = (doc) => {
        doc.querySelectorAll('script[type="application/json"]').forEach((s) => parseAndScan(s.textContent));
    };

    // Instagram loads posts with fetch / XHR, so listen to those answers.
    const originalFetch = window.fetch;
    if (originalFetch) {
        window.fetch = function () {
            const promise = originalFetch.apply(this, arguments);
            promise.then((res) => {
                try {
                    const type = (res.headers && res.headers.get('content-type')) || '';
                    if (/json|text|javascript/.test(type)) {
                        res.clone().text().then(parseAndScan).catch(() => {});
                    }
                } catch (_) {}
            }).catch(() => {});
            return promise;
        };
    }
    if (window.XMLHttpRequest) {
        const originalSend = XMLHttpRequest.prototype.send;
        XMLHttpRequest.prototype.send = function () {
            this.addEventListener('load', () => {
                try {
                    if (this.responseType === '' || this.responseType === 'text') parseAndScan(this.responseText);
                } catch (_) {}
            });
            return originalSend.apply(this, arguments);
        };
    }

    // Last resort: open the post's page and read the data it ships with.
    const fetchPost = async (code) => {
        for (const path of ['/reel/', '/p/']) {
            try {
                const res = await fetch(path + code + '/', { credentials: 'include' });
                if (!res.ok) continue;
                const html = await res.text();
                scanDocument(new DOMParser().parseFromString(html, 'text/html'));
                if (media[code]) return;
            } catch (_) {}
        }
    };

    // ---------- which post is on screen ----------

    const CODE_RE = /\/(?:p|reel|reels|tv)\/([A-Za-z0-9_-]+)/;
    const codeFromHref = (href) => {
        const m = href && href.match(CODE_RE);
        return m && m[1] !== 'audio' ? m[1] : null;
    };

    const currentCode = () => {
        // A post or reel page has the code in its address.
        const fromUrl = codeFromHref(location.pathname);
        if (fromUrl) return fromUrl;

        // Feed: climb from the middle of the screen until one post's links are found.
        let node = document.elementFromPoint(window.innerWidth / 2, window.innerHeight / 2);
        for (let i = 0; node && i < 16; i++, node = node.parentElement) {
            const links = node.querySelectorAll ? node.querySelectorAll('a[href*="/p/"], a[href*="/reel/"], a[href*="/reels/"]') : [];
            const codes = new Set();
            for (let j = 0; j < links.length && j < 40; j++) {
                const c = codeFromHref(links[j].getAttribute('href'));
                if (c) codes.add(c);
            }
            if (codes.size === 1) return Array.from(codes)[0];
            if (codes.size > 1) return null; // several posts: too vague
        }
        return null;
    };

    // Plain photos and videos that are not in the data (stories, for example).
    const visibleMedia = () => {
        const el = document.elementFromPoint(window.innerWidth / 2, window.innerHeight / 2);
        if (!el) return null;
        const root = el.closest('article, section, main') || el.parentElement || document.body;
        const video = root.querySelector('video');
        const src = video && (video.currentSrc || video.src);
        if (src && src.indexOf('blob:') !== 0) return { type: 'video', url: src };
        const images = Array.from(root.querySelectorAll('img')).filter((img) => {
            const r = img.getBoundingClientRect();
            return r.width > 150 && r.height > 150 && r.bottom > 0 && r.top < window.innerHeight;
        });
        if (!images.length) return null;
        const img = images.sort((a, b) =>
            b.getBoundingClientRect().width * b.getBoundingClientRect().height -
            a.getBoundingClientRect().width * a.getBoundingClientRect().height)[0];
        let best = img.currentSrc || img.src;
        if (img.srcset) {
            const parts = img.srcset.split(',').map((p) => p.trim().split(/\s+/));
            parts.sort((a, b) => (parseInt(b[1], 10) || 0) - (parseInt(a[1], 10) || 0));
            if (parts[0] && parts[0][0]) best = parts[0][0];
        }
        return best ? { type: 'image', url: best } : null;
    };

    // ---------- saving ----------

    const toast = (message) => window.InstaDownloadBridge && window.InstaDownloadBridge.toast &&
        window.InstaDownloadBridge.toast(message);

    const extOf = (url, type) => {
        const m = url.split('?')[0].match(/\.([a-z0-9]{3,4})$/i);
        return m ? m[1].toLowerCase() : (type === 'video' ? 'mp4' : 'jpg');
    };
    const mimeOf = (type, ext) => type === 'video' ? 'video/mp4'
        : ext === 'png' ? 'image/png' : ext === 'webp' ? 'image/webp' : 'image/jpeg';

    const save = (items, code) => {
        items.forEach((item, i) => {
            const ext = extOf(item.url, item.type);
            const name = 'instalite_' + code + (items.length > 1 ? '_' + (i + 1) : '') + '.' + ext;
            if (window.InstaDownloadBridge && window.InstaDownloadBridge.download) {
                window.InstaDownloadBridge.download(item.url, name, mimeOf(item.type, ext));
            }
        });
    };

    let busy = false;
    const onDownload = async () => {
        if (busy) return;
        busy = true;
        try {
            toast('Looking for the media…');
            const code = currentCode();
            if (code && !media[code]) scanDocument(document);
            if (code && !media[code]) await fetchPost(code);
            if (code && media[code]) { save(media[code].items, code); return; }

            const fallback = visibleMedia();
            if (fallback) { save([fallback], code || String(Date.now())); return; }
            toast("Couldn't find a photo or video here");
        } catch (e) {
            toast('Download failed');
        } finally {
            busy = false;
        }
    };

    // ---------- the button ----------

    const shouldShow = () =>
        /^\/($|reels?\/|reel\/|p\/|tv\/|stories\/|explore\/|[^/]+\/(p|reel)\/)/.test(location.pathname);

    const init = () => {
        const button = document.createElement('div');
        button.id = 'instalite-download';
        button.setAttribute('role', 'button');
        button.setAttribute('aria-label', 'Download');
        button.style.cssText =
            'position:fixed;left:12px;bottom:calc(88px + env(safe-area-inset-bottom,0px));' +
            'width:46px;height:46px;border-radius:50%;background:rgba(0,0,0,.6);display:none;' +
            'align-items:center;justify-content:center;z-index:2147483647;' +
            'box-shadow:0 2px 8px rgba(0,0,0,.4);-webkit-tap-highlight-color:transparent;';
        button.innerHTML = '<svg viewBox="0 0 24 24" width="24" height="24" fill="#fff">' +
            '<path d="M5 20h14v-2H5v2zM19 9h-4V3H9v6H5l7 7 7-7z"/></svg>';
        button.addEventListener('click', (e) => {
            e.stopPropagation();
            e.preventDefault();
            onDownload();
        });
        document.body.appendChild(button);

        const update = () => { button.style.display = shouldShow() ? 'flex' : 'none'; };
        ['pushState', 'replaceState'].forEach((name) => {
            const original = history[name];
            history[name] = function () {
                const result = original.apply(this, arguments);
                setTimeout(update, 0);
                return result;
            };
        });
        window.addEventListener('popstate', update);
        update();
        scanDocument(document);
    };

    if (document.body) init();
    else document.addEventListener('DOMContentLoaded', init);

    window.__instaLiteDownloadDebug = { scan, parseAndScan, media, codeFromHref };
})();
