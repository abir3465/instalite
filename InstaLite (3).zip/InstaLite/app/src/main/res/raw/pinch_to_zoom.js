// Zoom lock (light: watches only the viewport tag, not the whole page)
(function() {
    if (window.__instaLiteZoomLock) return;
    window.__instaLiteZoomLock = true;

    const CONTENT = "width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no";

    function apply() {
        let viewport = document.querySelector('meta[name="viewport"]');
        if (!viewport) {
            viewport = document.createElement('meta');
            viewport.name = "viewport";
            (document.head || document.documentElement).appendChild(viewport);
        }
        if (viewport.content !== CONTENT) viewport.content = CONTENT;
    }

    apply();
    document.addEventListener('DOMContentLoaded', apply);

    const viewport = document.querySelector('meta[name="viewport"]');
    if (viewport) {
        new MutationObserver(apply).observe(viewport, {
            attributes: true,
            attributeFilter: ['content']
        });
    }
})();
