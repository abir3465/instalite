// InstaLite base script (kept light: no polling timers)
(() => {
    // The native back button asks the page whether it handled "back" itself.
    window.backHandlerNB = () => "false";

    // Never start twice, even if the app injects this script again.
    if (window.__instaLiteInit) return;
    window.__instaLiteInit = true;

    const toHex = (value) => {
        if (!value) return null;
        value = value.trim();
        if (value.startsWith("#")) return value;
        const m = value.match(/^rgba?\(\s*(\d+)[,\s]+(\d+)[,\s]+(\d+)(?:[,\s/]+([\d.]+))?\s*\)$/);
        if (!m) return null;
        if (m[4] !== undefined && parseFloat(m[4]) === 0) return null;
        return "#" + [m[1], m[2], m[3]]
            .map(n => Number(n).toString(16).padStart(2, "0"))
            .join("");
    };

    // Tell the app which colour the page uses, so the status bar matches.
    let last = null;
    const notify = () => {
        const meta = document.querySelector('meta[name="theme-color"]');
        let color = toHex(meta && meta.content);
        if (!color && document.body) color = toHex(getComputedStyle(document.body).backgroundColor);
        if (!color) color = toHex(getComputedStyle(document.documentElement).backgroundColor);
        if (color && color !== last) {
            last = color;
            window.ThemeBridge?.onThemeColorChanged?.(color);
        }
    };

    notify();
    window.addEventListener("load", notify);
    document.addEventListener("visibilitychange", notify);
    // After a tap, check once more (page changes happen after taps), but never in a loop.
    let timer = null;
    document.addEventListener("click", () => {
        clearTimeout(timer);
        timer = setTimeout(notify, 700);
    }, true);
})();
