package com.instalite.app

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.view.WindowCompat
import com.instalite.app.ui.screens.InstaLiteWebView
import com.instalite.app.ui.theme.InstaLiteTheme
import com.instalite.app.utils.SmoothMotionState
import com.instalite.app.utils.applySmoothMotion

const val ACTION_OPEN_SETTINGS = "com.instalite.app.OPEN_SETTINGS"
private const val SETTINGS_ALIAS = "com.instalite.app.SettingsAlias"

private fun Intent?.isSettingsRequest(): Boolean =
    this != null && (action == ACTION_OPEN_SETTINGS || component?.className == SETTINGS_ALIAS)

class MainActivity : ComponentActivity() {
    private var openSettings by mutableStateOf(false)

    override fun onCreate(savedInstanceState: Bundle?) {
        WindowCompat.setDecorFitsSystemWindows(window, false)
        enableEdgeToEdge()
        super.onCreate(savedInstanceState)

        // The launcher shortcut "Settings" starts the app with this action.
        openSettings = savedInstanceState == null && intent.isSettingsRequest()

        val startUrl = intent?.data?.toString() ?: "https://www.instagram.com/"
        setContent {
            InstaLiteTheme {
                InstaLiteWebView(
                    url = startUrl,
                    openSettings = openSettings,
                    onSettingsHandled = { openSettings = false }
                )
            }
        }
    }

    override fun onResume() {
        super.onResume()
        applySmoothMotion(SmoothMotionState.enabled)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        if (intent.isSettingsRequest()) openSettings = true
    }
}
