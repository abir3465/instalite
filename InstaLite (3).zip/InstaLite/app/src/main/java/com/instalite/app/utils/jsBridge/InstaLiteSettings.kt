package com.instalite.app.utils.jsBridge

import android.webkit.JavascriptInterface

class InstaLiteSettings (
    private val toggleSettings: () -> Unit,
) {
    @JavascriptInterface
    @Suppress("unused")
    fun onSettingsToggle() = toggleSettings()
}