package com.instalite.app.utils

import java.net.URL
import java.net.URLDecoder

private val TRACKING_PARAMS = listOf("fbclid=", "igshid=", "igsh=")

fun fbRedirectSanitizer(link: String): String {
    try {
        var url = URL(link)

        // l.instagram.com / l.facebook.com wrap outgoing links, unwrap them.
        if ((url.host == "l.facebook.com" || url.host == "l.instagram.com") &&
            (url.path == "/l.php" || url.path == "/")
        ) {
            val target = url.query?.split("&")?.firstNotNullOfOrNull { part ->
                val kv = part.split("=", limit = 2)
                if (kv.size == 2 && kv[0] == "u") URLDecoder.decode(kv[1], "UTF-8") else null
            } ?: return link
            url = URL(target)
        }

        val params = url.query?.split("&")
            ?.filter { param -> TRACKING_PARAMS.none { param.startsWith(it) } }
            ?.joinToString("&")

        return buildString {
            append("${url.protocol}://${url.host}")
            if (url.port != -1 && url.port != url.defaultPort) append(":${url.port}")
            append(url.path)
            if (!params.isNullOrBlank()) append("?").append(params)
        }
    } catch (_: Exception) {
        return link
    }
}
