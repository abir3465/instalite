package com.instalite.app.utils.jsBridge

import android.app.DownloadManager
import android.content.Context
import android.net.Uri
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.webkit.JavascriptInterface
import android.widget.Toast
import com.instalite.app.R

/**
 * Lets the page hand a photo or video link to Android's download manager.
 * Only https links on Instagram / Facebook CDN hosts are accepted.
 */
class InstaDownloadBridge(
    private val context: Context,
    private val userAgent: String
) {
    private val main = Handler(Looper.getMainLooper())

    private fun show(message: String) {
        main.post { Toast.makeText(context, message, Toast.LENGTH_SHORT).show() }
    }

    @JavascriptInterface
    @Suppress("unused")
    fun toast(message: String?) {
        if (!message.isNullOrBlank()) show(message)
    }

    @JavascriptInterface
    @Suppress("unused")
    fun download(url: String?, fileName: String?, mimeType: String?) {
        val uri = runCatching { Uri.parse(url) }.getOrNull()
        val host = uri?.host?.lowercase()
        val allowed = uri != null && uri.scheme == "https" && host != null &&
            (host.endsWith("cdninstagram.com") || host.endsWith("fbcdn.net"))
        if (!allowed) {
            show(context.getString(R.string.download_not_allowed))
            return
        }

        val safeName = (fileName ?: "instalite_${System.currentTimeMillis()}")
            .replace(Regex("[^A-Za-z0-9._-]"), "_")

        runCatching {
            val request = DownloadManager.Request(uri)
                .setTitle(safeName)
                .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                .setAllowedOverMetered(true)
                .setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, "InstaLite/$safeName")
                .addRequestHeader("User-Agent", userAgent)
            if (!mimeType.isNullOrBlank()) request.setMimeType(mimeType)

            val manager = context.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
            manager.enqueue(request)
            show(context.getString(R.string.download_started))
        }.onFailure {
            show(context.getString(R.string.download_failed))
        }
    }
}
