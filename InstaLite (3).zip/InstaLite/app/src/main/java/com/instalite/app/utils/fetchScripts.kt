package com.instalite.app.utils

import androidx.annotation.RawRes
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

data class Script(
    val isEnabled: Boolean,
    @param:RawRes val resourceId: Int,
    val scriptTitle: String
)

/** Joins the bundled scripts that are enabled. Nothing is downloaded. */
suspend fun fetchScripts(
    scripts: List<Script>,
    fallbackContent: (Int) -> String
): String = withContext(Dispatchers.IO) {
    buildString {
        scripts.filter { it.isEnabled }.forEach { script ->
            append(fallbackContent(script.resourceId))
            append('\n')
        }
    }
}
