package com.instalite.app.utils

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.os.Build

/** Remembers the setting so the activity can re-apply it when it comes back to the screen. */
object SmoothMotionState {
    @Volatile
    var enabled: Boolean = true
}

fun Context.findActivity(): Activity? {
    var current: Context? = this
    while (current is ContextWrapper) {
        if (current is Activity) return current
        current = current.baseContext
    }
    return null
}

/**
 * Asks Android to keep this window at 60 Hz (on) or lets the system decide again (off).
 * It is a request: battery saver or heat can still lower the rate.
 */
fun Activity.applySmoothMotion(enabled: Boolean) {
    val rate = if (enabled) 60f else 0f
    val params = window.attributes
    var changed = false

    if (params.preferredRefreshRate != rate) {
        params.preferredRefreshRate = rate
        changed = true
    }
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
        if (params.preferredMinDisplayRefreshRate != rate) {
            params.preferredMinDisplayRefreshRate = rate
            changed = true
        }
        if (params.preferredMaxDisplayRefreshRate != rate) {
            params.preferredMaxDisplayRefreshRate = rate
            changed = true
        }
    }
    if (changed) window.attributes = params
}
