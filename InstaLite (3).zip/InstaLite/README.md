# InstaLite

A lightweight Android app that opens instagram.com in a web view, with a Material You settings screen.

Based on [Materialbook](https://github.com/eepiemi/Materialbook) by eepiemi (GPL-3.0), which is itself
based on Nobook. This project is also released under the GNU General Public License v3.0 (see LICENSE).
It is an unofficial client and is not affiliated with Instagram or Meta.

## Settings

Open the **InstaLite Settings** icon in your app drawer, or long-press the app icon and tap **Settings**. Options: pinch to zoom, desktop layout, immersive mode.

## Build

Run the **Build APK** workflow in GitHub Actions and download the `InstaLite-APK` artifact.
